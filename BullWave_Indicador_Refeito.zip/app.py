# Flask backend principal
print('BullWave está rodando')